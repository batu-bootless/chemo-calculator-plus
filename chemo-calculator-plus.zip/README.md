# ChemoCalculator+ (LabBuddy Mini)

## Install
```bash
npm install
```

## Run locally
```bash
npm run dev
```

## Build for production
```bash
npm run build
```

## Deploy to Netlify
1. Push this repo to GitHub.
2. Go to Netlify → New site from Git.
3. Select your repo, set build command to `npm run build` and publish directory to `dist/`.
4. Deploy.